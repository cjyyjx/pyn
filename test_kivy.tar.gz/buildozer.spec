[app]
title = KivyTest
package.name = kivytest
package.domain = org.pyandroid
source.dir = .
source.include_exts = py
version = 0.1
requirements = python3,kivy
orientation = portrait
fullscreen = 0

[buildozer]
log_level = 1
archs = arm64-v8a

[app:android]
android.api = 34
android.minapi = 21
android.ndk = 25b
android.gradle_dependencies = 'com.android.support:support-annotations:28.0.0'
android.permissions = INTERNET
android.archs = arm64-v8a
android.accept_sdk_license = True
